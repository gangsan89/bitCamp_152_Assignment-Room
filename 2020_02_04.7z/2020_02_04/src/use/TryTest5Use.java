package use;

import ����.TryCatchTest5;

public class TryTest5Use {

	public static void main(String[] args) {
		TryCatchTest5 test5 = new TryCatchTest5();
		test5.input();
		test5.resOutput();

	}

}
