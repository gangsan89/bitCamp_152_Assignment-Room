package use;

import ����.TryCatchTest4;

public class TryTestUse {
	public static void main(String[] args) {
		TryCatchTest4 test4 = new TryCatchTest4();
		test4.input();
		test4.calc();
		test4.resOutput();
		
	}
}
