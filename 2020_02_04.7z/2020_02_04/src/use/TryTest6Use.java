package use;

import ����.TryCatchTest6;

public class TryTest6Use {

	public static void main(String[] args) {
		TryCatchTest6 test6 = new TryCatchTest6();
		test6.input2();
		test6.resOutput();

	}

}
