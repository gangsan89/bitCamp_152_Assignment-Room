package sub;

import java.awt.event.WindowListener;

import a.InterfaceTest1;

public interface SubInterfaceTest1 extends WindowListener, InterfaceTest1 {

}
