package use;

import gui.Test1;

public class GUITest1Use {
	public static void main(String[] args) {
		Test1 test1 = new Test1();
		test1.setVisible(true);
	}
}
