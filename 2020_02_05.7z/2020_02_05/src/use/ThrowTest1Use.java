package use;

import exseption.ThrowTest1;

public class ThrowTest1Use {
	public static void main(String[] args) {
		ThrowTest1 test1 = new ThrowTest1(0, 1);
		test1.init();
		test1.output();
		
	}
}
