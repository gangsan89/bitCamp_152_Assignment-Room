package gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;
import javax.swing.BoxLayout;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import javax.swing.JLabel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import java.awt.FlowLayout;
import javax.swing.LayoutStyle.ComponentPlacement;
import java.awt.Color;

public class Sample extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Sample frame = new Sample();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Sample() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 400, 700);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JButton btnNewButton = new JButton("0");
		btnNewButton.setBounds(10, 581, 90, 70);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JLabel label = new JLabel("");
		label.setBounds(127, 21, 0, 0);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(132, 21, 0, 0);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(137, 21, 0, 0);
		
		JLabel label_3 = new JLabel("");
		label_3.setBounds(142, 21, 0, 0);
		
		JLabel label_4 = new JLabel("");
		label_4.setBounds(147, 21, 0, 0);
		
		JLabel label_5 = new JLabel("");
		label_5.setBounds(152, 21, 0, 0);
		
		JLabel label_6 = new JLabel("");
		label_6.setBounds(157, 21, 0, 0);
		
		JLabel label_7 = new JLabel("");
		label_7.setBounds(162, 21, 0, 0);
		
		JLabel label_8 = new JLabel("");
		label_8.setBounds(167, 21, 0, 0);
		
		JLabel label_9 = new JLabel("");
		label_9.setBounds(172, 21, 0, 0);
		
		JLabel label_10 = new JLabel("");
		label_10.setBounds(177, 21, 0, 0);
		
		JLabel label_11 = new JLabel("");
		label_11.setBounds(182, 21, 0, 0);
		
		JLabel label_12 = new JLabel("");
		label_12.setBounds(187, 21, 0, 0);
		
		JLabel label_13 = new JLabel("");
		label_13.setBounds(192, 21, 0, 0);
		
		JLabel label_14 = new JLabel("");
		label_14.setBounds(197, 21, 0, 0);
		
		JLabel label_15 = new JLabel("");
		label_15.setBounds(202, 21, 0, 0);
		
		JButton btnNewButton_5 = new JButton("4");
		btnNewButton_5.setBounds(10, 440, 90, 70);
		
		JLabel label_16 = new JLabel("");
		label_16.setBounds(251, 21, 0, 0);
		
		JButton btnNewButton_6 = new JButton("5");
		btnNewButton_6.setBounds(102, 440, 90, 70);
		
		JLabel label_17 = new JLabel("");
		label_17.setBounds(300, 21, 0, 0);
		
		JLabel label_18 = new JLabel("");
		label_18.setBounds(305, 21, 0, 0);
		
		JLabel label_19 = new JLabel("");
		label_19.setBounds(310, 21, 0, 0);
		
		JLabel label_20 = new JLabel("");
		label_20.setBounds(315, 21, 0, 0);
		
		JLabel label_21 = new JLabel("");
		label_21.setBounds(320, 21, 0, 0);
		
		JButton btnNewButton_8 = new JButton("7");
		btnNewButton_8.setBounds(10, 369, 90, 70);
		
		JButton btnNewButton_9 = new JButton("8");
		btnNewButton_9.setBounds(102, 369, 90, 70);
		
		JButton btnNewButton_10 = new JButton("9");
		btnNewButton_10.setBounds(192, 369, 90, 70);
		
		JButton btnNewButton_12 = new JButton("-");
		btnNewButton_12.setBounds(282, 509, 90, 70);
		
		JButton btnNewButton_13 = new JButton("*");
		btnNewButton_13.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_13.setBounds(282, 440, 90, 70);
		
		JButton btnNewButton_14 = new JButton("/");
		btnNewButton_14.setBounds(282, 369, 90, 70);
		
		JButton btnNewButton_15 = new JButton("<");
		btnNewButton_15.setBounds(282, 289, 90, 70);
		
		JButton btnNewButton_16 = new JButton("+");
		btnNewButton_16.setBounds(282, 581, 90, 70);
		
		JButton btnNewButton_17 = new JButton("%");
		btnNewButton_17.setBounds(10, 289, 90, 70);
		
		JButton btnNewButton_18 = new JButton("CE");
		btnNewButton_18.setBounds(102, 289, 90, 70);
		
		JButton btnNewButton_19 = new JButton("C");
		btnNewButton_19.setBounds(192, 289, 90, 70);
		btnNewButton_19.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JButton btnNewButton_2 = new JButton("1");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(10, 509, 90, 70);
		
		JButton btnNewButton_3 = new JButton("2");
		btnNewButton_3.setBounds(102, 509, 90, 70);
		
		JButton btnNewButton_4 = new JButton("3");
		btnNewButton_4.setBounds(192, 509, 90, 70);
		
		JButton btnNewButton_7 = new JButton("6");
		btnNewButton_7.setBounds(192, 440, 90, 70);
		
		JButton btnNewButton_1 = new JButton(".");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_1.setBounds(102, 581, 90, 70);
		
		JButton btnNewButton_11 = new JButton("=");
		btnNewButton_11.setBounds(192, 581, 90, 70);
	
		contentPane.setLayout(null);
		contentPane.add(btnNewButton);
		contentPane.add(label);
		contentPane.add(label_1);
		contentPane.add(label_2);
		contentPane.add(label_3);
		contentPane.add(label_4);
		contentPane.add(label_5);
		contentPane.add(label_6);
		contentPane.add(label_7);
		contentPane.add(label_8);
		contentPane.add(label_9);
		contentPane.add(label_10);
		contentPane.add(label_11);
		contentPane.add(label_12);
		contentPane.add(label_13);
		contentPane.add(label_14);
		contentPane.add(label_15);
		contentPane.add(btnNewButton_5);
		contentPane.add(label_16);
		contentPane.add(btnNewButton_6);
		contentPane.add(label_17);
		contentPane.add(label_18);
		contentPane.add(label_19);
		contentPane.add(label_20);
		contentPane.add(label_21);
		contentPane.add(btnNewButton_2);
		contentPane.add(btnNewButton_3);
		contentPane.add(btnNewButton_4);
		contentPane.add(btnNewButton_7);
		contentPane.add(btnNewButton_8);
		contentPane.add(btnNewButton_9);
		contentPane.add(btnNewButton_10);
		contentPane.add(btnNewButton_12);
		contentPane.add(btnNewButton_13);
		contentPane.add(btnNewButton_14);
		contentPane.add(btnNewButton_15);
		contentPane.add(btnNewButton_1);
		contentPane.add(btnNewButton_11);
		contentPane.add(btnNewButton_16);
		contentPane.add(btnNewButton_17);
		contentPane.add(btnNewButton_18);
		contentPane.add(btnNewButton_19);
		
		JButton btnNewButton_20 = new JButton("Record");
		btnNewButton_20.setBounds(275, 10, 97, 34);
		contentPane.add(btnNewButton_20);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.LIGHT_GRAY);
		panel.setBounds(10, 54, 362, 225);
		contentPane.add(panel);
	}
}
