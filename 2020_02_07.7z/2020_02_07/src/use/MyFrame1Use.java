package use;

import �̺�Ʈ�ڵ�.MyFrame5;

public class MyFrame1Use {
	public static void main(String[] args) {
		MyFrame5 frame1 = new MyFrame5();
		frame1.setVisible(true);
	}
}
