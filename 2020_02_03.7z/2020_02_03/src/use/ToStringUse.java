package use;

import str.Test1;
import str.ToStringTest;

public class ToStringUse {

	public static void main(String[] args) {
		ToStringTest tt1 = new ToStringTest();
		ToStringTest tt2 = new ToStringTest("�谭��", 32);//�������̵�
		Test1 		test1 = new Test1();
		System.out.println(tt1); //System.out.println(tt1.toString() ); �� ������
		System.out.println(tt2);
		System.out.println(test1);

	}

}
