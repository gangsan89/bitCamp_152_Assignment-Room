package use;

import b.SubClassDa;

public class SuperSubUse {

	public static void main(String[] args) {
		SubClassDa sub = new SubClassDa();
		sub.setAge(100);
		sub.output();

	}

}
