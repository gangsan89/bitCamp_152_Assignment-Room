package use;

import a.MySuper;

public class MySuperUse {
	public static void main(String[] args) {
		MySuper s1 = new MySuper();
		System.out.println("������");
		MySuper s2 = new MySuper(2);
	}
}
