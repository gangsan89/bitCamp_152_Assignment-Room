package a;

public class ThisSuperGeneMethodTest extends MySuper{
	public ThisSuperGeneMethodTest() {
		System.out.println("&&&&&&&&&&");
		System.out.println("***********");
	}
	public ThisSuperGeneMethodTest(String str, int n) {
		for(int i = 1; i<=n; i++) {
			System.out.println(str);
		}
	}
	public ThisSuperGeneMethodTest(String str) {
		/*
		 * for(int i = 1; i<=str.length(); i++) { 
		 * System.out.println(str); 
		 * }
		 */
		this();
		this("KimGangsan","KimGangsan".length());
	}
}
