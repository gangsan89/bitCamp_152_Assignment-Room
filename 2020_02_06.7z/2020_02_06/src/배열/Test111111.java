package �迭;

public class Test111111 {
	public static void main(String[] args) {
		int s = 7;
		for(int r=s; r>0; r-=3) {
//			System.out.println(r);
			for(int c=0; c<3; c++) {
				System.out.print(r+c);
			}System.out.println();
		}
		
		for(int r=0; r<3; r++) {
			System.out.println(s);
			s-=3;
		}
	}
}
