package �迭;

public class Test111113 {
	public static void main(String[] args) {
		int s = 7;
		
		int[][] datas = new int[3][];
		datas[0] = new int[3];
		datas[1] = new int[4];
		datas[2] = new int[5];
		
		for(int r=0; r < datas.length ; r++ ) {
			
			for(int c=0; c < datas[r].length ; c++ ) {
				datas[r][c] = s+c;
			}if(r < datas.length-1) {
				s-=datas[r+1].length;
			}else {
				
			}
		}
		for(int r=0; r < datas.length ; r++ ) {
			
			for(int c=0; c < datas[r].length ; c++ ) {
				System.out.print( datas[r][c]+ " " );
			}
			System.out.println();
		}
		System.out.println(datas[2][1]);
	}
}
